package a3matrix;


public class Matrix extends AMatrix{
    private double[][] dArray;
    public Matrix(int nRows,int nCols)
    {
        this.setCols(nCols);
        this.setRows(nRows);
        this.dArray = new double[nRows][nCols];
    }

    public Matrix(double[][] dArray)
    {
        this(dArray.length,dArray[0].length);
        for(int r=0;r<this.getRows();r++)
            for(int c=0;c<this.getCols();c++)
                this.dArray[r][c]=dArray[r][c];
    }

    public Matrix(AMatrix mMatrix)
    {
        this(((Matrix)mMatrix).dArray);
    }


    @Override
    protected double getElement(int nRow, int nCol) {
        return this.dArray[nRow-1][nCol-1];
    }

    @Override
    protected void setElement(int nRow, int nCol, double dVal) {
        this.dArray[nRow-1][nCol-1]=dVal;
    }

    @Override
    protected AMatrix createMatrix(int nRows, int nCols) {
        return new Matrix(nRows,nCols);
    }

    @Override
    protected AMatrix copyMatrix() {
        return new Matrix(this);
    }
    
    public void assignmentQue7method()
    {
    	 AMatrix mRs = this.copyMatrix();
         if(this.getRows()!=this.getCols()-1) {
             throw new IllegalArgumentException("Must be an augmented matrix");
         }
         
         
         System.out.println("The original matrix is:");
         System.out.println(this);

         
         //• Now just for testing we will apply guass jordan elimination method on our augumented matrix.                 
          AMatrix GuassJordanElimMatrix = (AMatrix) this.gaussJordanElimination();         
          
          
          //•	Create a coefficient matrix A from augmented  matrix
          AMatrix coefficientMatrix = new Matrix(getRows(), getCols()-1);
          for (int i = 1; i <= this.getRows(); i++)
          {             
              for (int j = 1; j < this.getCols(); j++)
              {                 
            	  coefficientMatrix.setElement(i, j, this.getElement(i, j));               
              }           
          }       
          System.out.println("The coefficient matrix A is:");
          System.out.println(coefficientMatrix);
          
          // •	Create a known matrix C (known values from the original augmented matrix
          AMatrix knownMatrix = new Matrix(getRows(), 1);
          for (int i = 1; i <= this.getRows(); i++)
          {                                         
            	  knownMatrix.setElement(i, 1, this.getElement(i, this.getCols()));                                       
          }       
          System.out.println("The known vector C is:");
          System.out.println(knownMatrix);


         //•	Create a solved matrix B (values from the solution matrix
          AMatrix SolvedMatrix = new Matrix(getRows(), 1);
          for (int i = 1; i <= GuassJordanElimMatrix.getRows(); i++)
          {                                         
        	  SolvedMatrix.setElement(i, 1, GuassJordanElimMatrix.getElement(i, GuassJordanElimMatrix.getCols()));                                       
          }       
          System.out.println("The solved vector B is:");
          System.out.println(SolvedMatrix);
          
          //•	Multiply A*B and display the result with an appropriate label
          AMatrix multipliedMatrix = (AMatrix) coefficientMatrix.Multiply(SolvedMatrix);
          System.out.println("multipliedMatrix   A * B is");
          System.out.println(multipliedMatrix);
          
          //•  finally display whether A*B is equal to C
          boolean isEqual = true;
          for (int i = 1; i <= multipliedMatrix.getRows(); i++)
          {      
        	 if (multipliedMatrix.getElement(i, 1) != knownMatrix.getElement(i, 1))  
        	{
				isEqual = false;
			}
          	                                      
          }  
          
          System.out.println("A*B = C is : " + isEqual);
         
    }
    
}
