package a3matrix;
public class Graphic extends Matrix{
    //Constructor to create a Graphic object based on a Matrix image
    public Graphic(Matrix image){
        super(image);
    }
    //Method will rotate a graphic
    public void rotate(double dCx, double dCy, double dAngle){
        //Assign this matrix as left matrix object
        AMatrix mLeftOp = this;
        //Declare right matrix object
        AMatrix mRs = null;
        //Create a matrix for right matrix object having same row number with left matrix, and 3 column
        mRs = createMatrix(mLeftOp.getRows(), 3);
        //For loop to assign value for each position in right matrix
        for(int r = 1; r <= mRs.getRows(); r++) {
            for (int c = 1; c <= mRs.getCols(); c++) {
                //If position is not on column 3,
                //Set element equal to the left matrix
                //Else, set all element in column 3 is 1
                if(c < 3){
                    mRs.setElement(r, c, mLeftOp.getElement(r,c));
                }else{
                    mRs.setElement(r,c,1);
                }
            }
        }
        //Translate the right matrix to the world position with (-dXc, -dCy)
        mRs = (AMatrix) mRs.Translate(-dCx, -dCy);
        //Create a new rotate matrix having 3 rows, 3 columns
        AMatrix rotateMatrix = createMatrix(3,3);
        //Assign value to rotate matrix so that where row = column, the value is 1
        //Otherwise, the value is 0
        for(int r = 1; r < 4; r++){
            for(int c = 1; c < 4; c++){
                if(r==c){
                    rotateMatrix.setElement(r, c, 1);
                }else{
                    rotateMatrix.setElement(r,c, 0);
                }
            }
        }
        //Set element at position (1, 1) is cosine of angle
        rotateMatrix.setElement(1, 1, Math.cos(dAngle));
        //Set element at position (1, 2) is sine of angle multiply with (-1)
        rotateMatrix.setElement(1, 2, (-1)*Math.sin(dAngle));
        //Set element at position (2, 1) is sine of angle
        rotateMatrix.setElement(2, 1, Math.sin(dAngle));
        //Set element at position (2, 2) is cosine of angle
        rotateMatrix.setElement(2, 2, Math.cos(dAngle));
        //Multiply the right matrix with the rotate matrix
        mRs = (AMatrix) mRs.Multiply(rotateMatrix);
        //Translate back the right matrix to the origin position
        mRs = (AMatrix) mRs.Translate(dCx, dCy);
        //Set all element of the original matrix
        for(int i = 1; i <= this.getRows(); i++){
            for(int j = 1; j < 3; j++){
                //Each element at (i, j) of origin matrix is equal to element at (i, j) of right matrix
                //except the column 3 of Right matrix
                this.setElement(i, j, mRs.getElement(i, j));
            }
        }
    }
    //Method to scale a matrix with an initial value (dx, dy) and (Sx, Sy)
    public void scale(double dCx, double dCy, double dSx, double dSy){
        //Assign this matrix as left matrix object
        AMatrix mLeftOp = this;
        //Declare right matrix object
        AMatrix mRs = null;
        //Create a matrix for right matrix object having same row number with left matrix, and 3 column
        mRs = createMatrix(mLeftOp.getRows(), 3);
        //For loop to assign value for each position in right matrix
        for(int r = 1; r <= mRs.getRows(); r++) {
            for (int c = 1; c <= mRs.getCols(); c++) {
                //If position is not on column 3,
                //Set element equal to the left matrix
                //Else, set all element in column 3 is 1
                if(c < 3){
                    mRs.setElement(r, c, mLeftOp.getElement(r,c));
                }else{
                    mRs.setElement(r,c,1);
                }
            }
        }
        //Translate the right matrix to the world position with (-dXc, -dCy)
        mRs = (AMatrix) mRs.Translate(-dCx, -dCy);
        //Create a new scale matrix having 3 rows, 3 columns
        AMatrix scaleMatrix = createMatrix(3,3);
        //Assign value to scale matrix so that where row = column, the value is 1
        //Otherwise, the value is 0
        for(int r = 1; r < 4; r++){
            for(int c = 1; c < 4; c++){
                if(r==c){
                    scaleMatrix.setElement(r, c, 1);
                }else{
                    scaleMatrix.setElement(r,c, 0);
                }
            }
        }
        //Set element at position (1, 1) is Sx
        scaleMatrix.setElement(1, 1, dSx);
        //Set element at position (2, 2) is Sy
        scaleMatrix.setElement(2, 2, dSy);
        //Multiply the right matrix with the scale matrix
        mRs = (AMatrix) mRs.Multiply(scaleMatrix);
        //Translate back the right matrix to the origin position
        mRs = (AMatrix) mRs.Translate(dCx, dCy);
        //Set all element of the original matrix
        for(int i = 1; i <= this.getRows(); i++){
            for(int j = 1; j < 3; j++){
                //Each element at (i, j) of origin matrix is equal to element at (i, j) of right matrix
                //except the column 3 of Right matrix
                this.setElement(i, j, mRs.getElement(i, j));
            }
        }
    }
    //Method to translate a matrix with an initial value (dx, dy)
    public void translate(double dCx, double dCy){
        //Assign this matrix as left matrix object
        AMatrix mLeftOp = this;
        //Declare right matrix object
        AMatrix mRs = null;
        //Create a matrix for right matrix object having same row number with left matrix, and 3 column
        mRs = createMatrix(mLeftOp.getRows(), 3);
        //For loop to assign value for each position in right matrix
        for(int r = 1; r <= mRs.getRows(); r++) {
            for (int c = 1; c <= mRs.getCols(); c++) {
                //If position is not on column 3,
                //Set element equal to the left matrix
                //Else, set all element in column 3 is 1
                if(c < 3){
                    mRs.setElement(r, c, mLeftOp.getElement(r,c));
                }else{
                    mRs.setElement(r,c,1);
                }
            }
        }
        //Create a new translate matrix having 3 rows, 3 columns
        AMatrix translateMatrix = createMatrix(3,3);
        //Assign value to scale matrix so that where row = column, the value is 1
        //Otherwise, the value is 0
        for(int r = 1; r < 4; r++){
            for(int c = 1; c < 4; c++){
                if(r==c){
                    translateMatrix.setElement(r, c, 1);
                }else{
                    translateMatrix.setElement(r,c, 0);
                }
            }
        }
        //Set element at position (3, 1) is dx
        translateMatrix.setElement(3, 1, dCx);
        //Set element at position (3, 2) is dy
        translateMatrix.setElement(3, 2, dCy);
        //Multiply the right matrix with the translate matrix
        mRs = (AMatrix) mRs.Multiply(translateMatrix);
        //Set all element of the original matrix
        for(int i = 1; i <= this.getRows(); i++){
            for(int j = 1; j < 3; j++){
                //Each element at (i, j) of origin matrix is equal to element at (i, j) of right matrix
                //except the column 3 of Right matrix
                this.setElement(i, j, mRs.getElement(i, j));
            }
        }
    }
    //Override to string method to print out the matrix
    @Override
    public String toString() {
        //Create an instance of string builder object
        StringBuilder sb = new StringBuilder();
        //Append title in string builder
        sb.append("x\ty\n");
        //For loop to append every element in matrix
        for(int r = 1; r <= this.getRows(); r++){
            for(int c = 1; c <= this.getCols(); c++){
                sb.append(this.getElement(r, c) + "\t");
            }
            sb.append("\n");
        }
        //Return string builder to string.
        return sb.toString();
    }
}
