package october;

public class AssignQ1Func1 extends ACFunction{
    @Override
    public double calculate(double x) {
        return Math.sqrt(4 - (x*x));
    }
}
