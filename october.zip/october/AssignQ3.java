package october;

public class AssignQ3 extends ACFunction{
    @Override
    public double calculate(double x) {
        return (0.025*x*x*x*x) - (0.175*x*x*x) - (0.15*x*x) + 1.8*x;
    }
}
