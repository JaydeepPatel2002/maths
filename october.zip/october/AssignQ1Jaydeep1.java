package october;



public class AssignQ1Jaydeep1 extends ACFunction{
    @Override
    public double calculate(double x) {
        return 0.666666667*Math.sin(x) ;
    }
}
