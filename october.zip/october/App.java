package october;

public class App {
    public static void main(String[] args) {
        IFunction func1 = new AssignQ3();
        System.out.println("Trying simple left rectangle rule for equation 1(a)");
        long time1 = System.currentTimeMillis(); // or System.nanoTime()

        System.out.println("::::---->"+ func1.TrapezoidRuleWithBool( 0 ,    6,
                1E-6,35, false));

        long time2 = System.currentTimeMillis(); // or System.nanoTime()
        System.out.println("result found in " + (time2 - time1));
//        System.out.println(func1.leftRectRuleEfficient(3.0,9.0,
//                1E-6,20));
//        System.out.println(func1.leftRectRuleEfficient(0,    10.0,
//                1E-6,35));
        long time3 = System.currentTimeMillis(); // or System.nanoTime()

        System.out.println("::::---->"+func1.TrapezoidRuleWithBool( 0 ,    6,
                1E-6,35 , true));
        long time4 = System.currentTimeMillis(); // or System.nanoTime()
        System.out.println("result found in " + (time4 - time3));
        
        

    }
}
