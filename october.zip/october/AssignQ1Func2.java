package october;

public class AssignQ1Func2 extends ACFunction{
    @Override
    public double calculate(double x) {
        return  (0.2)*( 0.01*(322 + (294*x) + (111*x*x) + (3*x*x*x)  ) - (24*x)/(1 + (x*x)) ) ;
    }
}
