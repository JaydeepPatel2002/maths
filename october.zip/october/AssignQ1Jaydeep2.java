package october;



public class AssignQ1Jaydeep2  extends ACFunction{
    @Override
    public double calculate(double x) {
        return 0.3989422804 * Math.exp((Math.pow(-x, 2))/2) ;
    }
}