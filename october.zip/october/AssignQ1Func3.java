package october;

public class AssignQ1Func3 extends ACFunction{
    @Override
    public double calculate(double x) {
        return  4 * (Math.log(x) / Math.log(2));
    }
}
